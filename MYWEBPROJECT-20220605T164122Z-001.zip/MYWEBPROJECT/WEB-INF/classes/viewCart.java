import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.util.*;
public class viewCart extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
	if(session==null)
	{
		out.println("session doesn't exist");
	}
	else{
		String item_id;
		String item_name;
		String quanty;
		String Price;
		String amount;
		
		out.println("<html><head><title>View Cart Table</title><style>.align-right{text-align: right; border: 0;} .o{text-align: center; border: 0;}{</style></head>");
		out.println("<body style='background-color:#E59866;'>");
		
			try  {  
				  Class.forName("com.mysql.jdbc.Driver");
                  String url = "jdbc:mysql://127.0.0.1/userdata";
                  Connection con=DriverManager.getConnection(url,"root","root");
	              Statement st=con.createStatement();
				  String query="Select * from carttable";
				   ResultSet rs = st.executeQuery( query );
				    if(rs.next()){
					 item_id=rs.getString("ItemId");
					 item_name=rs.getString("ItemName");
					 Price=rs.getString("price");
					 quanty=rs.getString("Quantity");
					 amount=rs.getString("TotalAmount");
					  out.println("<div class='align-right'>");
					 out.println("<button type='button'  style='height:40px;width:200px;'><a href='LogOutUser' target='_blank'>log out</a></button>");
					 out.println("</div>");
					 out.println("<h1> cart table consist of :</h1>");
					 
					 out.println("<p>Item Id:" +item_id+ "</p>");
					 
					 out.println("<p>Item Name:" +item_name+ "</p>");
				 
					  out.println("<p>Item quantity:" +quanty+ "</p>");
					  
					 out.println("<p>Item price:" +Price+ "</p>");
					 
					 out.println("<p>Total Amount is:" +amount+ "</p>");
					out.println("<form action='DeleteFromCart' method='get' >");
					out.println("<input type='hidden' name='id' value="+item_id+">");
					out.println("<input type='submit' value='DeleteFromCart'>");
					out.println("</form>");
					 out.println("<br>");
					 
					 out.println("</html>");
					
					  while(rs.next()){
					 item_id=rs.getString("ItemId");
					 item_name=rs.getString("ItemName");
					 Price=rs.getString("price");
					 quanty=rs.getString("Quantity");
					 amount=rs.getString("TotalAmount");
					 out.println("<hr>");
			//		 out.println("<h1> cart table consist of :</h1>");
					 
					 out.println("<p>Item Id:" +item_id+ "</p>");
					 
					 out.println("<p>Item Name:" +item_name+ "</p>");
				 
					  out.println("<p>Item quantity:" +quanty+ "</p>");
					  
					 out.println("<p>Item price:" +Price+ "</p>");
					 
					 out.println("<p>Total Amount is:" +amount+ "</p>");
					 out.println("<br>");
					 out.println("<form action='DeleteFromCart' method='get' >");
					out.println("<input type='hidden' name='id' value="+item_id+">");
					out.println("<input type='submit' value='DeleteFromCart'>");
					out.println("</form>");
					 out.println("</html>");
					 
					  } 
					  out.println("<div class='o'>");
					  out.println("<button style='height:40px;width:200px;'><a href='Order'>Order</a></button>");
					  out.println("</div>");
			      }
					else
					{
					response.sendError(response.SC_NOT_FOUND,"oops!!page cannot be found");
					}
		  st.close();
           con.close();
		   out.close();
	  } 
	   catch(Exception ex)
		{
		out.println(ex);
		}
	}
	}
	}