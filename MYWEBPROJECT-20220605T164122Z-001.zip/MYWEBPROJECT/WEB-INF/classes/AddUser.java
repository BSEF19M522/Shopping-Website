import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.util.*;

public class AddUser extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
	
	
    PrintWriter out = response.getWriter();
	
		HttpSession session = request.getSession(false);
	if(session==null)
	{
		out.println("session doesn't exist");
	}
	else{ 
	out.println("<html><head>");
out.println("	 <title>Add User</title>");
out.println("	<style>");
out.println("	form{ border:5px black solid;margin-left:200px;margin-right:200px;margin-top:100px;margin-bottom:200px;}");
out.println("	span{");
out.println("	     font-size:10px;");
out.println("		 color:red;");
out.println("		 }");
out.println(".align-right{text-align: right; border: 0;}");
out.println("	</style>	");
out.println("<script type='text/javascript'>");
out.println("function validate()");
out.println("{	");
out.println("	if ( document.signup.Username.value == '' )");
out.println("	    {");
out.println("			document.getElementById('msg1').innerHTML='**Username is empty';		");
out.println("			return false;");
out.println("	    }");
out.println("		else");
out.println("		{");
out.println("		document.getElementById('msg1').innerHTML='';");
out.println("		}");
out.println("	if ( document.signup.Firstname.value == '' )");
out.println("	    {");
out.println("			document.getElementById('msg2').innerHTML='**Firstname is empty';		");
out.println("			return false;");
out.println("	    }");
out.println("		else");
out.println("		{");
out.println("		document.getElementById('msg2').innerHTML='';");
out.println("		}");
out.println("	if ( document.signup.Lastname.value == '' )");
out.println("	    {");
out.println("			document.getElementById('msg3').innerHTML='**Lastname is empty';	");
out.println("			return false;");
out.println("	    }");
out.println("		else");
out.println("		{");
out.println("		document.getElementById('msg3').innerHTML='';");
out.println("		}");
out.println("	if(document.signup.password.value == '')	");
out.println("	   {");
out.println("			document.getElementById('msg4').innerHTML='**password is empty';");
out.println("			document.signup.password.focus();");
out.println("			return false;");
out.println("	   }");
out.println("	   else");
out.println("		{");
out.println("		document.getElementById('msg4').innerHTML='';");
out.println("		}");
out.println("if(document.signup.confrmpass.value == ''||document.signup.confrmpass.value!=document.signup.password.value)	");
out.println("	   {");
out.println("			document.getElementById('msg5').innerHTML='**password and confirm password doesnt match';");
out.println("			document.signup.confrmpass.focus();");
out.println("			return false;");
out.println("	   }		");
out.println("else");
out.println("		{");
out.println("		document.getElementById('msg5').innerHTML='';");
out.println("		}");
out.println("	if ( document.signup.address.value == '' )");
out.println("	{	");
out.println("			document.getElementById('msg7').innerHTML='**address is empty';");
out.println("			return false;");
out.println("	}");
out.println("	else");
out.println("		{");
out.println("		document.getElementById('msg7').innerHTML='';");
out.println("		}");
out.println("	if ( document.signup.city.value == '' )");
out.println("	{		document.getElementById('msg9').innerHTML='**city is empty';");
out.println("			return false;");
out.println("	}");
out.println("	else");
out.println("		{");
out.println("		document.getElementById('msg9').innerHTML='';");
out.println("		}");
out.println("");
out.println("	if ( document.signup.phone.value == '' )");
out.println("	{		");
out.println("			document.getElementById('msg8').innerHTML='**Phone number is empty';");
out.println("			return false;");
out.println("	}");
out.println("	else");
out.println("		{");
out.println("		document.getElementById('msg8').innerHTML='';");
out.println("		}");
out.println("			");
out.println("	if ( document.signup.email.value == '' )		");
out.println("{");
out.println("		document.getElementById('msg6').innerHTML='**Email is empty';");
out.println("		return false;");
out.println("	}");
out.println("	else");
out.println("		{");
out.println("		document.getElementById('msg6').innerHTML='';");
out.println("		}       ");
out.println("return true;");
out.println("");
out.println("}");
out.println("function letternumber(event)");
out.println("	{");
out.println("		var keychar;");
out.println("			");
out.println("		keychar = event.key;");
out.println("		");
out.println("		");
out.println("		// alphas and numbers");
out.println("		if ((('.+-0123456789').indexOf(keychar) > -1))");
out.println("		   return true;");
out.println("		else");
out.println("		   return false;");
out.println("	}");
out.println("</script>");
out.println("	</head><body style='background-color:#E59866;'>");
out.println("<div class='align-right'>");
out.println("<button type='button'  style='height:40px;width:200px'><a href='LogOutAdmin' target='_blank'> LOG OUT</a></button>");
out.println("</div>");
out.println("	<form name='signup' onsubmit='return validate()' method='post' action='addUserAdmin'>");
out.println("	<table  border='0' align='center'>");
out.println("	<tr><td ><input type='text' name='Username' id='Username' size='30' placeholder='Username'></td>");
out.println("	 <td> <span id='msg1'> </span></td>");
out.println("	</tr>");
out.println("	<tr><td ><input type='text' name='Firstname'  size='30' placeholder='Firstname'></td> ");
out.println("	 <td> <span id='msg2'> </span></td>");
out.println("	</tr>");
out.println("	<tr><td ><input type='text' name='Lastname' size='30' placeholder='Lastname'></td>");
out.println("	 <td> <span id='msg3'> </span></td>");
out.println("	</tr>");
out.println("	<tr><td ><input type='text' name='password'  size='30' placeholder='Password'></td>");
out.println("	 <td> <span id='msg4'> </span></td>");
out.println("	</tr> ");
out.println("	<tr><td ><input type='text' name='confrmpass' size='30'  placeholder='confirm password'></td> ");
out.println("	 <td> <span id='msg5'> </span></td>");
out.println("	</tr>");
out.println("	<tr><td ><input type='email' name='email' size='30' placeholder='Email'></td> ");
out.println("	 <td> <span id='msg6'> </span></td>");
out.println("	</tr>");
out.println("	<tr><td ><input type='text' name='address' size='30' placeholder='Addresss'></td>");
out.println("	 <td> <span id='msg7'> </span></td>");
out.println("	</tr> ");
out.println("	<tr><td ><input type='text' name='phone' size='30' placeholder='Phone Number' onKeyPress='return letternumber(event)' ></td>");
out.println("	 <td> <span id='msg8'> </span></td>");
out.println("	</tr> ");
out.println("	<tr><td ><input type='text' name='city' size='30' placeholder='city'></td> ");
out.println("	 <td> <span id='msg9'> </span></td>");
out.println("	</tr> ");
out.println("	<tr><td ><input type='submit' value='Add User'></td></tr> ");
out.println("	</table>");
out.println("	</form>");
out.println("	</body>");
out.println("	</html>");

	}
	}
}
   