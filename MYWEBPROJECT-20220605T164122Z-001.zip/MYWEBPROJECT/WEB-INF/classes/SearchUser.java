import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.util.*;
public class SearchUser extends HttpServlet {

public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();
		String email=request.getParameter("email");
	    String password=request.getParameter("password");
			try  {  
				  Class.forName("com.mysql.jdbc.Driver");
                  String url = "jdbc:mysql://127.0.0.1/userdata";
                  Connection con=DriverManager.getConnection(url,"root","root");
	              Statement st=con.createStatement();
				  String query="Select * from insertdata where email='"+email+"' AND password='"+password+"'  ";
				   ResultSet rs = st.executeQuery( query );
				    if(rs.next()){
					 HttpSession session = request.getSession(true);
					 response.sendRedirect("mainMenu");
					}
					else
					{
					response.sendError(response.SC_NOT_FOUND,"oops!!page cannot be found");
					}
		  st.close();
           con.close();
	  } 
	   catch(Exception ex)
		{
		out.println(ex);
		}
	}
	}