import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.util.*;
import java.sql.*;
import javax.swing.*;


public class RRemoveItem extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
	
	
	response.setContentType("text/html");
    PrintWriter out = response.getWriter();
	
		HttpSession session = request.getSession(false);
	if(session==null)
	{
		out.println("session doesn't exist");
	}
	else{
		          
	             String itemId=request.getParameter("ItemId");
				 
	             String name=request.getParameter("Name");
				
               
				 
	try  {  
				  Class.forName("com.mysql.jdbc.Driver");
                  String url = "jdbc:mysql://127.0.0.1/userdata";
                  Connection con=DriverManager.getConnection(url,"root","root");
	              Statement st=con.createStatement();
				  String que="Select * from itemtable where ItemId='"+itemId+"' AND Name='"+name+"' ";
				    ResultSet rs = st.executeQuery( que );   
					  
					  if (rs.next())
					  {
						  String quantity =rs.getString("Quantity");
						  int x=Integer.parseInt(quantity);
						  if(x>1)
						  {
							  x--;
				             String que1="Update itemtable set Quantity="+x+" where ItemId='"+itemId+"' AND Name='"+name+"' " ;	
                            int rs1 = st.executeUpdate( que1);
		                      if(rs1>0)
		                      {
			                 out.println("records updated successfully");
		                     }					 
						  }
			             else{
							  
			               String query="delete from itemtable where ItemId='"+itemId+"' AND Name='"+name+"' ";
	                       int rs2= st.executeUpdate( query );
		                         if(rs2>0)
		                          {
			                     out.println("records deleted successfully");
		                          }
		                         else
		                          {
			                      response.sendError(404,"not matched");
		                           }
						 }
				  }
				  else{
					   response.sendError(404,"not found");
				  }
		con.close();
	}//try
		   catch(Exception ex)
		{
		out.println(ex);
		} 
           
		   out.close();
	  
	}
}
} 