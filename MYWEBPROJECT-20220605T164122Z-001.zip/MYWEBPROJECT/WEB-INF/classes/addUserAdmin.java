import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.util.*;
import java.sql.*;
import javax.swing.*;


public class addUserAdmin extends HttpServlet {

public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
	
	
	response.setContentType("text/html");
    PrintWriter out = response.getWriter();
		          
	             String Uname=request.getParameter("Username");
				 
	             String Fname=request.getParameter("Firstname");
				 
	             String Lname=request.getParameter("Lastname");
				 
                 String pass=request.getParameter("password");
				 
				 String cpass=request.getParameter("confrmpass");
				  
                 String mail=request.getParameter("email");
				 
				 String adress=request.getParameter("address");
				 
                 String phn=request.getParameter("phone");
				 
				 String cit=request.getParameter("city");
				 
	try  {  
				  Class.forName("com.mysql.jdbc.Driver");
                  String url = "jdbc:mysql://127.0.0.1/userdata";
                  Connection con=DriverManager.getConnection(url,"root","root");
	              Statement st=con.createStatement();
				//  String query="insert into insertdata(Username,Firstname,Lastname,password,confrmpass,email,address,phone,city)values('"+Uname+"','"+Fname+"','"+Lname+"','"+pass+"','"+cpass+"','"+mail+"','"+adress+"','"+phn+"','"+cit+"')";
	       // int rs = st.executeUpdate( query );
		 String query="Select * from insertdata where email='"+mail+"' ";
		 ResultSet rs = st.executeQuery( query );   
	    if(rs.next())
				{
					
			response.sendError(404,"oops!!records duplication");
				}
	    else
		{
		  String que="insert into insertdata(Username,Firstname,Lastname,password,confrmpass,email,address,phone,city)values('"+Uname+"','"+Fname+"','"+Lname+"','"+pass+"','"+cpass+"','"+mail+"','"+adress+"','"+phn+"','"+cit+"')";
	       int r = st.executeUpdate( que );
		   if(r>0)
		   {
			   out.println("records inserted successfully");
		   }
		}
		con.close();
	}
		   catch(Exception ex)
		{
		out.println(ex);
		} 
           
		   out.close();
	  
	}
}
	   