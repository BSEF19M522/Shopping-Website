import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.util.*;
import java.sql.*;
import javax.swing.*;


public class RRemoveUser extends HttpServlet {

public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
	
	
	response.setContentType("text/html");
    PrintWriter out = response.getWriter();
	
		HttpSession session = request.getSession(false);
	if(session==null)
	{
		out.println("session doesn't exist");
	}
	else{
		 String username=request.getParameter("Username");         
	    String email=request.getParameter("email");
	    
				
               
				 
	try  {  
				  Class.forName("com.mysql.jdbc.Driver");
                  String url = "jdbc:mysql://127.0.0.1/userdata";
                  Connection con=DriverManager.getConnection(url,"root","root");
	              Statement st=con.createStatement();
			 String query="delete from insertdata where Username='"+username+"' AND email='"+email+"' ";
	       int rs = st.executeUpdate( query );
		   if(rs>0)
		   {
			   out.println("records deleted successfully");
		   }
		   else
		   {
			   response.sendError(404,"record not deleted");
		}
		con.close();
	}//try
		   catch(Exception ex)
		{
		out.println(ex);
		} 
           
		   out.close();
	}
	}
}
	   