import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.util.*;
public class ReviewItem extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession(false);
	if(session==null)
	{
		out.println("session doesn't exist");
	}
	else{
		String item_id;
		String item_name;
		String cat;
		String quanty;
		String Price;
		
		out.println("<html><head><title>View Items Collection</title><style>.align-right{text-align: right; border: 0;}</style></head>");
		out.println("<body style='background-color:#E59866;'>");
		
			try  {  
				  Class.forName("com.mysql.jdbc.Driver");
                  String url = "jdbc:mysql://127.0.0.1/userdata";
                  Connection con=DriverManager.getConnection(url,"root","root");
	              Statement st=con.createStatement();
				  String query="Select * from itemtable";
				   ResultSet rs = st.executeQuery( query );
				    if(rs.next()){
							item_id=rs.getString("ItemId");
					 item_name=rs.getString("Name");
					 cat=rs.getString("Category");
					 quanty=rs.getString("Quantity");
					 Price=rs.getString("Price");
					 out.println("<div class='align-right'>");
                     out.println("<button type='button'  style='height:40px;width:200px'><a href='LogOutAdmin' target='_blank'> LOG OUT</a></button>");
                     out.println("</div>");
					 out.println("<h1> The collection of accessories are as follows:</h1>");
					 
					 out.println("<p>Item Id:" +item_id+ "</p>");
					 
					 out.println("<p>Item Name:" +item_name+ "</p>");
					
					 out.println("<p>Item category:" +cat+ "</p>");
					 
					  out.println("<p>Item quantity:" +quanty+ "</p>");
					  
					 out.println("<p>Item price:" +Price+ "</p>");
					 out.println("<br>");
					 
					 out.println("</html>");
					 
			         while(rs.next()){		 
            			item_id=rs.getString("ItemId");
					 item_name=rs.getString("Name");
					 cat=rs.getString("Category");
					 quanty=rs.getString("Quantity");
					 Price=rs.getString("Price");
					 out.println("<hr>");
					 
					 out.println("<p>Item Id:" +item_id+ "</p>");
					 
					 out.println("<p>Item Name:" +item_name+ "</p>");
					
					 out.println("<p>Item category:" +cat+ "</p>");
					 
					  out.println("<p>Item quantity:" +quanty+ "</p>");
					  
					 out.println("<p>Item price:" +Price+ "</p>");
					 out.println("<br>");
					
					 out.println("</html>");
					}}
					else
					{
					response.sendError(response.SC_NOT_FOUND,"oops!!page cannot be found");
					}
		  st.close();
           con.close();
		   out.close();
	  } 
	   catch(Exception ex)
		{
		out.println(ex);
		}
	}
	}
	}