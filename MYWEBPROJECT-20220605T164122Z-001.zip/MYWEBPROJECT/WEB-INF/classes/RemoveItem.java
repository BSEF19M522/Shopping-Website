import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.util.*;

public class RemoveItem extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
	
	
    PrintWriter out = response.getWriter();
	
		HttpSession session = request.getSession(false);
	if(session==null)
	{
		out.println("session doesn't exist");
	}
	else{
    out.println("<html>");
out.println("<head><title>Removing Item</title>");
out.println("<style>");
out.println(".align-right{text-align: right; border: 0;}");
out.println("form{ border:5px black solid;");
out.println("margin-left:200px;");
out.println("margin-right:200px;");
out.println("margin-bottom:200px;");
out.println("margin-top:100px;}");
out.println("span{");
out.println("	     font-size:10px;");
out.println("		 color:red;");
out.println("		 }");
out.println("</style>");
out.println("<script>		");
out.println("function validate()");
out.println("{	");
out.println("");
out.println("	if ( document.items.ItemId.value == '' )");
out.println("	    {");
out.println("			document.getElementById('msg1').innerHTML='**item id is empty';		");
out.println("			return false;");
out.println("	    }");
out.println("		else{");
out.println("		document.getElementById('msg1').innerHTML='';");
out.println("		}	");
out.println("if ( document.items.Name.value == '' )		");
out.println("{");
out.println("		document.getElementById('msg2').innerHTML='**Name is empty';");
out.println("		return false;");
out.println("	}");
out.println("else{");
out.println("		document.getElementById('msg2').innerHTML='';");
out.println("		}    ");
out.println("return true;");
out.println("}");
out.println("</script>");
out.println("</head>");
out.println("<body style='background-color:#E59866;'>");
out.println("	</head><body style='background-color:#E59866;'>");
out.println("<div class='align-right'>");
out.println("<button type='button'  style='height:40px;width:200px'><a href='LogOutAdmin' target='_blank'> LOG OUT</a></button>");
out.println("</div>");
out.println("	<form name='items'  onsubmit='return validate()' method='get' action='RRemoveItem' >");
out.println("	<table  border='0' align='center'>");
out.println("	<tr><td ><input type='text' name='ItemId' id='ItemId' size='45' placeholder='Item Id'></td>");
out.println("	<td> <span id='msg1'> </span></td>");
out.println("	</tr>");
out.println("<tr><td ><input type='text' name='Name'  size='45' placeholder='Item name'></td> ");
out.println("	<td> <span id='msg2'> </span></td>");
out.println("	</tr>");
out.println("	<tr><td ><input type='submit' value='Remove Item'></td></tr>");
out.println("	</table>");
out.println("	</form>");
out.println("	</body>");
out.println("	</html>");
	}
	}
}
   