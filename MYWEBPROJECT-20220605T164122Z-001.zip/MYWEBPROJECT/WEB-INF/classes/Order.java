import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.util.*;

public class Order extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
	response.setContentType("text/html");
    PrintWriter out = response.getWriter();
	HttpSession session = request.getSession(false);
	if(session==null)
	{
		out.println("session doesn't exist");
	}
	else{
		out.println("<html><head><title>Order</title><style>.align-right{text-align: right; border: 0;}</style></head>");
		out.println("<body style='background-color:#E59866;'>");
		out.println("<div class='align-right'>");
					 out.println("<button type='button'  style='height:40px;width:200px;'><a href='LogOutUser' target='_blank'>log out</a></button>");
					 out.println("</div>");
			try  {  
				  Class.forName("com.mysql.jdbc.Driver");
                  String url = "jdbc:mysql://127.0.0.1/userdata";
                  Connection con=DriverManager.getConnection(url,"root","root");
	              Statement st=con.createStatement();
				  String query="Select * from carttable";
				   ResultSet rs = st.executeQuery( query );
				   int amount=0;
				   if(rs.next())
				   {
					   out.println("<p> Amount of "+rs.getString("ItemName")+" is "+rs.getString("TotalAmount")+"</p>");
					   int a=Integer.parseInt(rs.getString("TotalAmount"));
					   amount=amount+a;
					    while(rs.next())
				   {
					   
					   out.println("<p>Amount of "+rs.getString("ItemName")+" is "+rs.getString("TotalAmount")+"</p>");
					    a=Integer.parseInt(rs.getString("TotalAmount"));
					   amount=amount+a; 
				   }//while close
				   
				   }//if close
				   out.println("<b><p>Total Amount is: " +amount+ "</p></b>");
			}//try 
	
	    catch(Exception ex)
		{
		out.println(ex);
		}
	}
	}
}