import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.util.*;
public class AddtoCart extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
	if(session==null)
	{
		out.println("session doesn't exist");
	}
	else{
		String name=request.getParameter("name");
		String id=request.getParameter("id");
		String price=request.getParameter("price");
		String quantity=request.getParameter("quantity");
		
		
		int q=Integer.parseInt(quantity);
	if(q>1){
         q=1;
	       }		 // one item will be add at a time
		   int p=Integer.parseInt(price);
		int total=p*q;
		
		try
		{
				 Class.forName("com.mysql.jdbc.Driver");
                  String url = "jdbc:mysql://127.0.0.1/userdata";
                  Connection con=DriverManager.getConnection(url,"root","root");
	              Statement st=con.createStatement();
				    String que="Select * from carttable where ItemId='"+id+"' AND ItemName='"+name+"' ";
				    ResultSet rs1 = st.executeQuery( que );   
				  if(rs1.next()){
							
						 String qquantity =rs1.getString("Quantity");
						 int x=Integer.parseInt(qquantity)+q;
						 int a=x*p;
						 String que1="Update carttable set TotalAmount="+a+", Quantity="+x+" where ItemId='"+id+"' AND ItemName='"+name+"'  " ;	
						 int rs2 = st.executeUpdate( que1);
				        if(rs2>0)
				         {
				         out.println("records updated successfully");
				         }			
					  
					  
					  
				  }
				  else{
					   String sql="insert into carttable (ItemId,ItemName,price,Quantity,TotalAmount) values('"+id+"','"+name+"','"+price+"',"+q+",'"+total+"' )";
						int rs=st.executeUpdate(sql);
						if(rs>0)
						{
						out.println("Success");
						}
						else
						{
						out.println("Failure");
						}
		              }
		}
		catch(Exception ex){out.println(ex);}
		
	}
	}
	}