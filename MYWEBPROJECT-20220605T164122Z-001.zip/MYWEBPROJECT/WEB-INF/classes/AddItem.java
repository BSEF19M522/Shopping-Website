import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.util.*;

public class AddItem extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
	
	
    PrintWriter out = response.getWriter();
	
		HttpSession session = request.getSession(false);
	if(session==null)
	{
		out.println("session doesn't exist");
	}
	else{
	out.println("<html>");
out.println("<head>");
out.println("<title>Adding Item</title>");
out.println("<style>");
out.println("form{ border:5px black solid;margin-left:200px;");
out.println("margin-right:200px;margin-bottom:200px;");
out.println("		  margin-top:100px;}");
out.println("span{");
out.println("font-size:10px;");
out.println("color:red;");
out.println("}");
out.println(".align-right{text-align: right; border: 0;}");
out.println("</style>");
out.println("<script>");
out.println("function validate()");
out.println("{	");
out.println("if ( document.items.ItemId.value == '' )");
out.println("{");
out.println("document.getElementById('msg1').innerHTML='**item id is empty';		");
out.println("return false;");
out.println("}");
out.println("else{");
out.println("document.getElementById('msg1').innerHTML='';");
out.println("}");
out.println("if ( document.items.Name.value == '' )		");
out.println("{");
out.println("document.getElementById('msg2').innerHTML='**Name is empty';");
out.println("return false;");
out.println("}");
out.println("else{");
out.println("document.getElementById('msg2').innerHTML='';");
out.println("} ");
out.println("	if(document.items.Category.value == '')	");
out.println("	   {");
out.println("			document.getElementById('msg3').innerHTML='**Category is empty';");
out.println("			return false;");
out.println("	   }	");
out.println("	 else{");
out.println("		document.getElementById('msg3').innerHTML='';");
out.println("		}");
out.println("		");
out.println("	if(document.items.Quantity.value == '')	");
out.println("	   {");
out.println("			document.getElementById('msg4').innerHTML='**Quantity is empty';");
out.println("			return false;");
out.println("	   }	");
out.println("	 else{");
out.println("		document.getElementById('msg4').innerHTML='';");
out.println("		}");
out.println("	if(document.items.Price.value == '')	");
out.println("	   {");
out.println("			document.getElementById('msg5').innerHTML='**Price is empty';");
out.println("			return false;");
out.println("	   }	");
out.println("	 else{");
out.println("		document.getElementById('msg5').innerHTML='';");
out.println("		}");
out.println("	return true;");
out.println("}");
out.println("</script>");

out.println("</head>");
out.println("<body style='background-color:#E59866;'>");
out.println("<div class='align-right'>");
out.println("<button type='button'  style='height:40px;width:200px'><a href='LogOutAdmin' target='_blank'> LOG OUT</a></button>");
out.println("</div>");
out.println("	<form name='items' onsubmit='return validate()' method='post'  action='InsertItem' >");
out.println("	<table  border='0' align='center'>");
out.println("	<tr><td ><input type='text' name='ItemId' id='ItemId' size='45' placeholder='Item Id'></td>");
out.println("	<td> <span id='msg1'> </span></td>");
out.println("	</tr>");
out.println("<tr><td ><input type='text' name='Name'   size='45' placeholder='Item name'></td> ");
out.println("	<td> <span id='msg2'> </span></td>");
out.println("	</tr>");
out.println("	<tr><td ><input type='text' name='Category' size='45' placeholder='item Category'></td>");
out.println("	<td> <span id='msg3'> </span></td>");
out.println("	</tr>");
out.println("	<tr><td ><input type='text' name='Quantity' size='45' placeholder='Quantity'></td> ");
out.println("	<td> <span id='msg4'> </span></td>");
out.println("	</tr> ");
out.println("	<tr> <td ><input type='text' name='Price' size='45' placeholder='Item price' ></td>  ");
out.println("	<td> <span id='msg5'> </span></td>");
out.println("	</tr> ");
out.println("	<tr><td ><input type='submit'value='Add Item'></td>");
out.println("	</tr>");
out.println("	</table></form>");
out.println("	</body>");
out.println("	</html>");

	}
	}
}
   