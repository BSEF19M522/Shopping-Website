import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;

public class mainMenuAdmin extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
	
	
    PrintWriter out = response.getWriter();
	
		HttpSession session = request.getSession(false);
	if(session==null)
	{
		out.println("session doesn't exist");
	}
	else{
    out.println("<html><head><title>Main MENU PAGE</title><style>  span{ margin-left:450px;margin-right:200px;margin-top:150px;</style></head>");
    out.println("<body style='background-color:#E59866;' > ");
	
	out.println("<h1 align='center'><i>Main menu page</i></h1>");
	out.println("<br>");
	out.println("<span>");
    out.println("<button type='button' style='height:40px;width:200px'><a href='AddItem' target='_blank'>Add Items</a></button>");
	out.println("</span>");
	out.println("<br>");
	out.println("<br>");
	out.println("<span>");
	out.println("<button type='button'  style='height:40px;width:200px'><a href='RemoveItem' target='_blank'>Remove Item</a></button>");
	out.println("</span>");
	out.println("<br>");
	out.println("<br>");
	out.println("<span>");
	out.println("<button type='button'  style='height:40px;width:200px'><a href='AddUser' target='_blank'>Add User</a></button>");
	out.println("</span>");
	out.println("<br>");
	out.println("<br>");
	out.println("<span>");
	out.println("<button type='button'  style='height:40px;width:200px'><a href='RemoveUser' target='_blank'>Remove User</a></button>");
	out.println("</span>");
	out.println("<br>");
	out.println("<br>");
	out.println("<span>");
	out.println("<button type='button'  style='height:40px;width:200px'><a href='ReviewItem' target='_blank'>Review Items</a></button>");
	out.println("</span>");
	out.println("<br>");
	out.println("<br>");
	out.println("<span>");
	out.println("<button type='button'  style='height:40px;width:200px'><a href='GenerateInvoice' target='_blank'>Generate Invoice</a></button>");
	out.println("</span>");
	out.println("<br>");
	out.println("<br>");
	out.println("<span>");
	out.println("<button type='button'  style='height:40px;width:200px'><a href='LogOutAdmin' target='_blank'> LOG OUT</a></button>");
	out.println("</span>");
    out.println("</body>");
    out.println("</html>");
   
	out.close(); 
	}
	
	}
	

}