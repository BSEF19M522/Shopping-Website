import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.util.*;
import java.sql.*;
import javax.swing.*;


public class DeleteFromCart extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
	
	
	response.setContentType("text/html");
    PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
	if(session==null)
	{
		out.println("session doesn't exist");
	}
	else{          
	             
				 
	String itemId=request.getParameter("id");
				 
	           
				
               
				 
	try  {  
				  Class.forName("com.mysql.jdbc.Driver");
                  String url = "jdbc:mysql://127.0.0.1/userdata";
                  Connection con=DriverManager.getConnection(url,"root","root");
	              Statement st=con.createStatement();
				  String que="Select * from carttable where ItemId='"+itemId+"' ";
				    ResultSet rs1 = st.executeQuery( que );   
				  if(rs1.next()){
					  String quantity=rs1.getString("Quantity");
					  int x=Integer.parseInt(quantity);
					  if(x>1)
					  {
						  // total amount will also be decreased with quantity
						 int totalprice=Integer.parseInt(rs1.getString("TotalAmount"));
						 int price=Integer.parseInt(rs1.getString("price"));
						 int updatedprice=totalprice-price;
						 x--;
						  String que1="Update carttable set  TotalAmount="+updatedprice+" ,Quantity="+x+" where ItemId='"+itemId+"' " ;	
                            int rs2 = st.executeUpdate( que1);
		                      if(rs2>0)
		                      {
			                 out.println("records updated successfully");
		                     }				
					  }
					  else
					  {
												  
							 String query="delete from carttable where ItemId='"+itemId+"'";
						   int rs = st.executeUpdate( query );
						   if(rs>0)
						   {
							   out.println("records deleted successfully");
						   }
						   else
						   {
							   response.sendError(404,"not matched");
						   }
					  }
				  }
				  else{
					  
					  response.sendError(404,"not found");		
				  }
				  
		
		con.close();
	}//try
		   catch(Exception ex)
		{
		out.println(ex);
		} 
           
		   out.close();
	}
	  
	}
}
	   