import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;

public class mainMenu extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{        
	
	
    PrintWriter out = response.getWriter();
	HttpSession session = request.getSession(false);
	if(session==null)
	{
		out.println("session doesn't exist");
	}
	else{
    out.println("<html><head><title>Main MENU PAGE</title><style> span{margin-left:200px;margin-right:200px;margin-top:150px;</style></head>");
    out.println("<body style='background-color:#E59866;' > ");
	out.println("<h1 align='center'><i>Main menu page</i></h1>");
	out.println("<br>");
	out.println("<span>");
    out.println("<button type='button' style='height:40px;width:200px'><a href='viewItem' target='_blank'>View Items</a></button>");
	out.println("</span>");
	out.println("<br>");
	out.println("<br>");
	out.println("<span>");
	out.println("<button type='button'  style='height:40px;width:200px'><a href='viewCart' target='_blank'>View cart</a></button>");
	out.println("</span>");
	out.println("<br>");
	out.println("<br>");
	out.println("<span>");
	out.println("<button type='button'  style='height:40px;width:200px'><a href='LogOutUser' target='_blank'>log out</a></button>");
	out.println("</span>");
    out.println("</body>");
    out.println("</html>");
    }
	out.close(); 

	
	}


}